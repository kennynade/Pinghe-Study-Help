# Vercel 部署说明（无服务器版）

> 适用：同学能在 Vercel 上部署，且有/愿意买一个域名。
> 架构：**Vercel 静态托管 + Serverless 函数（API） + Vercel KV（数据） + Vercel Blob（图片）**。
> 特点：电脑不用开机、免运维；但国内访问**不一定稳定**（尤其 `*.vercel.app`），所以**强烈建议绑定自己的域名**。

---

## 一、部署前准备

| 项 | 说明 |
|---|---|
| Vercel 账号 | 用 GitHub 或邮箱注册即可，免费 Hobby 计划 |
| GitHub 账号（可选） | 用 Git 仓库导入最方便 |
| 域名（强烈建议） | 阿里云/腾讯云买一个便宜域名（约 ¥30–60/年），**不需要备案**（解析到海外） |
| Node（可选） | 想用命令行部署才需要 |

代码已经改造好：`api/index.js`（Serverless API）、`package.json`（依赖 `@vercel/kv` / `@vercel/blob`）、`vercel.json`、`.vercelignore`。

---

## 二、上传代码

### 方式 A：GitHub 仓库（推荐）

1. 把 `错题站-Vercel部署包.zip` 解压，内容推到自己的 GitHub 仓库（一个班一个仓库就行）
2. Vercel → Add New → Project → 导入这个仓库
3. Framework Preset 选 **Other**，Root Directory 保持默认，点 Deploy（第一次会因为没有存储而报错/功能不全，先继续）

### 方式 B：命令行

```bash
# 在解压后的目录里
npm i -g vercel
vercel        # 首次会登录、创建项目
vercel --prod # 生产部署
```

---

## 三、创建两个存储（关键）

Vercel 项目页 → **Storage**：

1. **Upstash Redis（KV）**
   - Create Database → 选 Upstash Redis → 免费计划 → Connect 到本项目
   - 会自动注入环境变量 `KV_REST_API_URL`、`KV_REST_API_TOKEN`

2. **Blob**
   - Create → Blob → Connect 到本项目
   - 会自动注入 `BLOB_READ_WRITE_TOKEN`

> ⚠️ 两个都必须连。少连一个的话：
> - 没连 KV → 数据存内存，**刷新/重启就全丢**（页面「设置 → 存储状态」会显示 `storage: memory ⚠️`）
> - 没连 Blob → 图片上传会失败

---

## 四、环境变量

Vercel 项目 → Settings → Environment Variables：

| 名称 | 值 | 说明 |
|---|---|---|
| `REGISTER_CODE` | 自己定，如 `class2026` | 注册邀请码，**一定要设** |

保存后 **Redeploy** 一次。

---

## 五、绑定域名（解决国内访问）

1. Vercel 项目 → Settings → **Domains** → Add，填入你的域名（如 `cuoti.example.com`）
2. 按 Vercel 提示到域名服务商处加 DNS 记录：
   - 子域名：`CNAME → cname.vercel-dns.com`
   - 根域名：`A → 76.76.21.21`（以 Vercel 页面提示为准）
3. 等 DNS 生效（几分钟到几小时），Vercel 自动签发 HTTPS 证书
4. 用手机 4G 打开 `https://你的域名` 测一下稳定性

> `*.vercel.app` 在大陆经常打不开；**绑定自己的域名会好很多，但仍不保证稳定**。
> 如果测下来还是慢/断，建议换回国内云服务器（见 `部署说明.md`）。

---

## 六、部署后检查清单

- [ ] `https://你的域名/` 能打开登录页
- [ ] 注册第一个账号 → 自动成为管理员
- [ ] 「设置 → 存储状态」显示 **数据存储 kv / 图片 blob**（不是 memory）
- [ ] 上传一道带图的题 → 图片能显示
- [ ] 提交一次作答 → 显示"待批改"
- [ ] 「设置 → AI 实时批改」填智谱 Key → 提交作答能自动批改
- [ ] 用手机/iPad 打开测一次

---

## 七、限制与注意

| 限制 | 说明 |
|---|---|
| 函数超时 | 已设 `maxDuration: 60`；AI 批改偶尔超时可点「⚡ 立即批改」重试 |
| KV 单文档大小 | 所有文字数据存在一个 JSON 里；**图片在 Blob 不占 KV**，一个班几百道题没问题 |
| 免费额度 | Hobby 有函数调用/带宽/Blob 存储额度，一个班正常使用够 |
| 数据备份 | 管理员可访问 `/api/admin/backup` 导出 JSON；图片在 Blob 控制台可下载 |
| 单点数据竞争 | 极少数情况下两人同时写会覆盖，班级规模可接受 |

---

## 八、常见问题

**Q：注册后刷新，账号/题目全没了**
→ KV 没连上，正在用内存模式。检查 Storage 是否 Connect，以及环境变量 `KV_REST_API_URL`。

**Q：传图片失败**
→ Blob 没连上，或图片超过 8MB。

**Q：AI 批改报 401**
→ Key 不对/过期，去智谱控制台重新复制。

**Q：AI 批改报 504 / 超时**
→ 模型响应慢，点「立即批改」重试；或换 `glm-5.3-flashx`。

**Q：国内打开很慢/打不开**
→ 用自定义域名（已绑定 HTTPS）；仍不行就换国内服务器方案。
